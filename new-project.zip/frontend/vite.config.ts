import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

const BACKEND_PORT = 8000
const FRONTEND_PORT = 5173
const PUBLIC_HOST = `0a6239c4-${FRONTEND_PORT}-2-base.preview.verdent.ai`

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    host: '0.0.0.0',
    port: FRONTEND_PORT,
    allowedHosts: true,
    hmr: {
      host: PUBLIC_HOST,
      protocol: 'wss',
      clientPort: 443,
    },
    proxy: {
      '/api': `http://127.0.0.1:${BACKEND_PORT}`,
      '/media': `http://127.0.0.1:${BACKEND_PORT}`,
      '/outputs': `http://127.0.0.1:${BACKEND_PORT}`,
    },
  },
})
