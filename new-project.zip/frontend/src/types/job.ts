export interface Segment {
  id: number
  start: number
  end: number
  text: string
  include: boolean
}

export type JobStatus =
  | 'queued'
  | 'processing'
  | 'review_ready'
  | 'done'
  | 'failed'

export interface JobStatusResponse {
  job_id: string
  status: JobStatus
  step?: string | null
  error?: string | null
  progress?: number | null
  source_url?: string | null
  source_media_url?: string | null
  duration?: number | null
  segments?: Segment[] | null
  output_url?: string | null
}
