from __future__ import annotations

import os
import shutil
import uuid

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from starlette.concurrency import run_in_threadpool

from . import config, pipeline
from .job_manager import job_manager
from .models import CreateJobRequest, JobStatusResponse, RenderRequest

app = FastAPI(title="Kirinuki Auto Editor")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/media", StaticFiles(directory=config.WORK_DIR), name="media")
app.mount("/outputs", StaticFiles(directory=config.OUTPUTS_DIR), name="outputs")


@app.on_event("startup")
async def _startup() -> None:
    job_manager.start()


def _to_response(job) -> JobStatusResponse:
    return JobStatusResponse(
        job_id=job.job_id,
        status=job.status,
        step=job.step,
        error=job.error,
        progress=job.progress,
        source_url=job.source_url,
        source_media_url=job.source_media_url,
        duration=job.duration,
        segments=job.segments,
        output_url=job.output_url,
    )


@app.post("/api/jobs", response_model=JobStatusResponse)
async def create_job(req: CreateJobRequest) -> JobStatusResponse:
    if not req.url or not req.url.strip().lower().startswith(("http://", "https://")):
        raise HTTPException(status_code=400, detail="有効なURLを入力してください")
    job = job_manager.create_analyze_job(req.url.strip())
    return _to_response(job)


@app.post("/api/jobs/upload", response_model=JobStatusResponse)
async def upload_job(file: UploadFile = File(...)) -> JobStatusResponse:
    ext = os.path.splitext(file.filename or "")[1].lower()
    if ext not in config.ALLOWED_UPLOAD_EXTENSIONS:
        allowed = ", ".join(sorted(config.ALLOWED_UPLOAD_EXTENSIONS))
        raise HTTPException(
            status_code=400,
            detail=f"対応していないファイル形式です(対応形式: {allowed})",
        )

    job_id = uuid.uuid4().hex[:12]
    job_dir = os.path.join(config.WORK_DIR, job_id)
    os.makedirs(job_dir, exist_ok=True)
    tmp_path = os.path.join(job_dir, f"upload{ext}")

    size = 0
    try:
        with open(tmp_path, "wb") as f:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > config.MAX_UPLOAD_BYTES:
                    raise HTTPException(
                        status_code=400,
                        detail=f"ファイルサイズが大きすぎます(上限 {config.MAX_UPLOAD_BYTES // (1024 * 1024)}MB)",
                    )
                f.write(chunk)
    except HTTPException:
        shutil.rmtree(job_dir, ignore_errors=True)
        raise
    finally:
        await file.close()

    try:
        video_path = await run_in_threadpool(pipeline.prepare_uploaded_video, tmp_path, job_dir)
    except pipeline.PipelineError as exc:
        shutil.rmtree(job_dir, ignore_errors=True)
        raise HTTPException(status_code=400, detail=str(exc))

    job = job_manager.create_upload_job(job_id, video_path, file.filename or "アップロード動画")
    return _to_response(job)


@app.get("/api/jobs/{job_id}", response_model=JobStatusResponse)
async def get_job(job_id: str) -> JobStatusResponse:
    job = job_manager.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="ジョブが見つかりません")
    return _to_response(job)


@app.post("/api/jobs/{job_id}/render", response_model=JobStatusResponse)
async def render_job(job_id: str, req: RenderRequest) -> JobStatusResponse:
    job = job_manager.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="ジョブが見つかりません")
    if job.status != "review_ready":
        raise HTTPException(status_code=400, detail="現在このジョブは書き出しできる状態ではありません")
    if not req.segments:
        raise HTTPException(status_code=400, detail="区間が指定されていません")
    job = job_manager.enqueue_render(job_id, req.segments)
    return _to_response(job)


@app.get("/api/health")
async def health() -> dict:
    return {"ok": True}
