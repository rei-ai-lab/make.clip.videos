from __future__ import annotations

from typing import List, Optional
from pydantic import BaseModel


class Segment(BaseModel):
    id: int
    start: float
    end: float
    text: str
    include: bool = True


class CreateJobRequest(BaseModel):
    url: str


class RenderRequest(BaseModel):
    segments: List[Segment]


class JobStatusResponse(BaseModel):
    job_id: str
    status: str
    step: Optional[str] = None
    error: Optional[str] = None
    progress: Optional[float] = None
    source_url: Optional[str] = None
    source_media_url: Optional[str] = None
    duration: Optional[float] = None
    segments: Optional[List[Segment]] = None
    output_url: Optional[str] = None
