from __future__ import annotations

import glob
import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from typing import Callable, List, Optional

from . import config
from .models import Segment

_whisper_model = None


def get_whisper_model():
    global _whisper_model
    if _whisper_model is None:
        from faster_whisper import WhisperModel

        _whisper_model = WhisperModel(
            config.WHISPER_MODEL_SIZE,
            device=config.WHISPER_DEVICE,
            compute_type=config.WHISPER_COMPUTE_TYPE,
        )
    return _whisper_model


class PipelineError(Exception):
    pass


def _run(cmd: List[str]) -> None:
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if proc.returncode != 0:
        raise PipelineError(
            f"command failed ({' '.join(cmd[:2])}...): {proc.stderr[-2000:]}"
        )


def probe_duration(path: str) -> float:
    cmd = [
        config.FFPROBE_BIN,
        "-v",
        "error",
        "-show_entries",
        "format=duration",
        "-of",
        "default=noprint_wrappers=1:nokey=1",
        path,
    ]
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if proc.returncode != 0:
        raise PipelineError(f"ffprobe failed: {proc.stderr[-1000:]}")
    try:
        return float(proc.stdout.strip())
    except ValueError:
        raise PipelineError("could not determine media duration")


def fetch_info(url: str) -> dict:
    import yt_dlp

    ydl_opts = {"quiet": True, "skip_download": True, "noplaylist": True}
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=False)
    return info


def download_video(url: str, job_dir: str) -> str:
    import yt_dlp

    out_path = os.path.join(job_dir, "source.%(ext)s")
    ydl_opts = {
        "quiet": True,
        "noprogress": True,
        "no_warnings": True,
        "noplaylist": True,
        "format": (
            f"bestvideo[height<={config.DOWNLOAD_MAX_HEIGHT}]+bestaudio/"
            f"best[height<={config.DOWNLOAD_MAX_HEIGHT}]/best"
        ),
        "merge_output_format": "mp4",
        "outtmpl": out_path,
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        ydl.download([url])

    candidates = glob.glob(os.path.join(job_dir, "source.*"))
    candidates = [c for c in candidates if not c.endswith(".part")]
    if not candidates:
        raise PipelineError("動画のダウンロードに失敗しました")

    src = candidates[0]
    if not src.endswith(".mp4"):
        dst = os.path.join(job_dir, "source.mp4")
        _run([
            config.FFMPEG_BIN, "-y", "-i", src,
            "-c:v", "libx264", "-c:a", "aac", dst,
        ])
        os.remove(src)
        src = dst
    return src


def prepare_uploaded_video(tmp_path: str, job_dir: str) -> str:
    dst = os.path.join(job_dir, "source.mp4")
    ext = os.path.splitext(tmp_path)[1].lower()
    if ext == ".mp4":
        shutil.move(tmp_path, dst)
    else:
        _run([
            config.FFMPEG_BIN, "-y", "-i", tmp_path,
            "-c:v", "libx264", "-c:a", "aac", dst,
        ])
        os.remove(tmp_path)
    return dst


def extract_audio(video_path: str, job_dir: str) -> str:
    audio_path = os.path.join(job_dir, "audio.wav")
    _run([
        config.FFMPEG_BIN, "-y", "-i", video_path,
        "-vn", "-ac", "1", "-ar", "16000", audio_path,
    ])
    return audio_path


def transcribe(audio_path: str) -> List[dict]:
    model = get_whisper_model()
    segments_iter, _info = model.transcribe(
        audio_path, language="ja", word_timestamps=False, vad_filter=True
    )
    raw = []
    for seg in segments_iter:
        text = seg.text.strip()
        if not text:
            continue
        raw.append({"start": seg.start, "end": seg.end, "text": text})
    return raw


def build_segments(raw: List[dict], duration: float) -> List[Segment]:
    if not raw:
        return []

    merged: List[dict] = []
    for seg in raw:
        if merged and seg["start"] - merged[-1]["end"] <= config.MERGE_GAP_SEC:
            merged[-1]["end"] = seg["end"]
            merged[-1]["text"] = (merged[-1]["text"] + " " + seg["text"]).strip()
        else:
            merged.append(dict(seg))

    segments: List[Segment] = []
    for i, seg in enumerate(merged):
        start = max(0.0, seg["start"] - config.PAD_SEC)
        end = min(duration, seg["end"] + config.PAD_SEC)
        if end <= start:
            continue
        segments.append(Segment(id=i, start=round(start, 2), end=round(end, 2), text=seg["text"], include=True))
    return segments


def _srt_escape(text: str) -> str:
    return text.replace("\n", " ")


def _write_srt(path: str, text: str, duration: float) -> None:
    def fmt(t: float) -> str:
        ms = int(round(t * 1000))
        h, ms = divmod(ms, 3600_000)
        m, ms = divmod(ms, 60_000)
        s, ms = divmod(ms, 1000)
        return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

    with open(path, "w", encoding="utf-8") as f:
        f.write("1\n")
        f.write(f"{fmt(0)} --> {fmt(duration)}\n")
        f.write(_srt_escape(text) + "\n\n")


def render_segments(
    source_path: str,
    segments: List[Segment],
    job_dir: str,
    output_path: str,
    on_progress: Optional[Callable[[int, int], None]] = None,
) -> None:
    included = [s for s in segments if s.include]
    included.sort(key=lambda s: s.start)
    if not included:
        raise PipelineError("採用された区間がありません")

    clips_dir = os.path.join(job_dir, "clips")
    os.makedirs(clips_dir, exist_ok=True)

    clip_paths = []
    total = len(included)
    for idx, seg in enumerate(included):
        clip_duration = max(0.05, seg.end - seg.start)
        srt_path = os.path.join(clips_dir, f"seg_{idx:03d}.srt")
        clip_path = os.path.join(clips_dir, f"seg_{idx:03d}.mp4")
        _write_srt(srt_path, seg.text, clip_duration)

        escaped_srt = srt_path.replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")
        vf = (
            f"subtitles='{escaped_srt}':force_style="
            "'FontName=Noto Sans CJK JP,FontSize=20,PrimaryColour=&H00FFFFFF,"
            "OutlineColour=&H00000000,BorderStyle=1,Outline=2,Alignment=2,MarginV=40'"
        )

        cmd = [
            config.FFMPEG_BIN, "-y",
            "-ss", f"{seg.start:.3f}",
            "-i", source_path,
            "-t", f"{clip_duration:.3f}",
            "-vf", vf,
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
            "-c:a", "aac",
            "-avoid_negative_ts", "make_zero",
            clip_path,
        ]
        _run(cmd)
        clip_paths.append(clip_path)
        if on_progress:
            on_progress(idx + 1, total)

    list_path = os.path.join(clips_dir, "concat_list.txt")
    with open(list_path, "w", encoding="utf-8") as f:
        for p in clip_paths:
            escaped = p.replace("'", "'\\''")
            f.write(f"file '{escaped}'\n")

    concat_cmd = [
        config.FFMPEG_BIN, "-y",
        "-f", "concat", "-safe", "0",
        "-i", list_path,
        "-c", "copy",
        output_path,
    ]
    _run(concat_cmd)

    shutil.rmtree(clips_dir, ignore_errors=True)
