from __future__ import annotations

import asyncio
import os
import shutil
import time
import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from . import config, pipeline
from .models import Segment


@dataclass
class Job:
    job_id: str
    source_url: str
    status: str = "queued"
    step: Optional[str] = None
    error: Optional[str] = None
    progress: Optional[float] = None
    duration: Optional[float] = None
    segments: Optional[List[Segment]] = None
    source_path: Optional[str] = None
    source_media_url: Optional[str] = None
    output_path: Optional[str] = None
    output_url: Optional[str] = None
    created_at: float = field(default_factory=time.time)

    @property
    def job_dir(self) -> str:
        d = os.path.join(config.WORK_DIR, self.job_id)
        os.makedirs(d, exist_ok=True)
        return d


class JobManager:
    def __init__(self) -> None:
        self.jobs: Dict[str, Job] = {}
        self._queue: "asyncio.Queue[tuple[str, str]]" = asyncio.Queue()
        self._worker_task: Optional[asyncio.Task] = None

    def start(self) -> None:
        if self._worker_task is None:
            self._worker_task = asyncio.create_task(self._worker_loop())

    def get(self, job_id: str) -> Optional[Job]:
        return self.jobs.get(job_id)

    def create_analyze_job(self, url: str) -> Job:
        job_id = uuid.uuid4().hex[:12]
        job = Job(job_id=job_id, source_url=url, status="queued", step="queued")
        self.jobs[job_id] = job
        self._queue.put_nowait((job_id, "analyze"))
        return job

    def create_upload_job(self, job_id: str, source_path: str, filename: str) -> Job:
        job = Job(
            job_id=job_id,
            source_url=filename,
            status="queued",
            step="queued",
            source_path=source_path,
        )
        self.jobs[job_id] = job
        self._queue.put_nowait((job_id, "analyze_upload"))
        return job

    def enqueue_render(self, job_id: str, segments: List[Segment]) -> Job:
        job = self.jobs[job_id]
        job.segments = segments
        job.status = "queued"
        job.step = "queued"
        job.error = None
        self._queue.put_nowait((job_id, "render"))
        return job

    async def _worker_loop(self) -> None:
        while True:
            job_id, kind = await self._queue.get()
            job = self.jobs.get(job_id)
            if job is None:
                self._queue.task_done()
                continue
            try:
                if kind == "analyze":
                    await self._do_analyze(job)
                elif kind == "analyze_upload":
                    await self._do_analyze_upload(job)
                elif kind == "render":
                    await self._do_render(job)
            except Exception as exc:  # noqa: BLE001
                job.status = "failed"
                job.error = str(exc)
            finally:
                self._queue.task_done()

    async def _do_analyze(self, job: Job) -> None:
        loop = asyncio.get_running_loop()
        job.status = "processing"
        job.step = "info"
        try:
            info = await loop.run_in_executor(None, pipeline.fetch_info, job.source_url)
            duration = info.get("duration")
            if duration and duration > config.MAX_DURATION_SEC:
                raise pipeline.PipelineError(
                    f"動画が長すぎます(上限 {config.MAX_DURATION_SEC // 60}分)"
                )

            job.step = "downloading"
            video_path = await loop.run_in_executor(
                None, pipeline.download_video, job.source_url, job.job_dir
            )

            actual_duration = await loop.run_in_executor(None, pipeline.probe_duration, video_path)
            if actual_duration > config.MAX_DURATION_SEC:
                raise pipeline.PipelineError(
                    f"動画が長すぎます(上限 {config.MAX_DURATION_SEC // 60}分)"
                )

            job.step = "extracting_audio"
            audio_path = await loop.run_in_executor(
                None, pipeline.extract_audio, video_path, job.job_dir
            )

            job.step = "transcribing"
            raw = await loop.run_in_executor(None, pipeline.transcribe, audio_path)

            job.step = "building_segments"
            segments = pipeline.build_segments(raw, actual_duration)
            if not segments:
                raise pipeline.PipelineError("音声が検出できませんでした")

            job.duration = actual_duration
            job.segments = segments
            job.source_path = video_path
            job.source_media_url = f"/media/{job.job_id}/source.mp4"
            job.status = "review_ready"
            job.step = "review_ready"
        except pipeline.PipelineError as exc:
            job.status = "failed"
            job.error = str(exc)
        except Exception as exc:  # noqa: BLE001
            job.status = "failed"
            job.error = f"予期しないエラー: {exc}"

    async def _do_analyze_upload(self, job: Job) -> None:
        loop = asyncio.get_running_loop()
        job.status = "processing"
        job.step = "checking"
        try:
            video_path = job.source_path
            if not video_path or not os.path.exists(video_path):
                raise pipeline.PipelineError("アップロードされたファイルが見つかりません")

            actual_duration = await loop.run_in_executor(None, pipeline.probe_duration, video_path)
            if actual_duration > config.MAX_DURATION_SEC:
                raise pipeline.PipelineError(
                    f"動画が長すぎます(上限 {config.MAX_DURATION_SEC // 60}分)"
                )

            job.step = "extracting_audio"
            audio_path = await loop.run_in_executor(
                None, pipeline.extract_audio, video_path, job.job_dir
            )

            job.step = "transcribing"
            raw = await loop.run_in_executor(None, pipeline.transcribe, audio_path)

            job.step = "building_segments"
            segments = pipeline.build_segments(raw, actual_duration)
            if not segments:
                raise pipeline.PipelineError("音声が検出できませんでした")

            job.duration = actual_duration
            job.segments = segments
            job.source_media_url = f"/media/{job.job_id}/source.mp4"
            job.status = "review_ready"
            job.step = "review_ready"
        except pipeline.PipelineError as exc:
            job.status = "failed"
            job.error = str(exc)
        except Exception as exc:  # noqa: BLE001
            job.status = "failed"
            job.error = f"予期しないエラー: {exc}"

    async def _do_render(self, job: Job) -> None:
        loop = asyncio.get_running_loop()
        job.status = "processing"
        job.step = "rendering"
        try:
            if not job.source_path or not job.segments:
                raise pipeline.PipelineError("解析データがありません")

            output_path = os.path.join(config.OUTPUTS_DIR, f"{job.job_id}.mp4")

            def _progress(done: int, total: int) -> None:
                job.progress = done / total if total else None
                job.step = f"rendering ({done}/{total})"

            await loop.run_in_executor(
                None,
                pipeline.render_segments,
                job.source_path,
                job.segments,
                job.job_dir,
                output_path,
                _progress,
            )

            job.output_path = output_path
            job.output_url = f"/outputs/{job.job_id}.mp4"
            job.status = "done"
            job.step = "done"

            shutil.rmtree(job.job_dir, ignore_errors=True)
        except pipeline.PipelineError as exc:
            job.status = "failed"
            job.error = str(exc)
        except Exception as exc:  # noqa: BLE001
            job.status = "failed"
            job.error = f"予期しないエラー: {exc}"


job_manager = JobManager()
