import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROJECT_ROOT = os.path.dirname(BASE_DIR)

STORAGE_DIR = os.path.join(PROJECT_ROOT, "storage")
DOWNLOADS_DIR = os.path.join(STORAGE_DIR, "downloads")
OUTPUTS_DIR = os.path.join(STORAGE_DIR, "outputs")
WORK_DIR = os.path.join(STORAGE_DIR, "work")

for d in (DOWNLOADS_DIR, OUTPUTS_DIR, WORK_DIR):
    os.makedirs(d, exist_ok=True)

FFMPEG_BIN = os.environ.get("FFMPEG_BIN", "/workspace/tools/bin/ffmpeg")
FFPROBE_BIN = os.environ.get("FFPROBE_BIN", "/workspace/tools/bin/ffprobe")

# MVP limits
MAX_DURATION_SEC = int(os.environ.get("MAX_DURATION_SEC", 60 * 10))  # 10 min
DOWNLOAD_MAX_HEIGHT = 720

# Local file upload limits
ALLOWED_UPLOAD_EXTENSIONS = {".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v"}
MAX_UPLOAD_BYTES = int(os.environ.get("MAX_UPLOAD_BYTES", 500 * 1024 * 1024))  # 500MB

# Whisper
WHISPER_MODEL_SIZE = os.environ.get("WHISPER_MODEL_SIZE", "small")
WHISPER_DEVICE = os.environ.get("WHISPER_DEVICE", "cpu")
WHISPER_COMPUTE_TYPE = os.environ.get("WHISPER_COMPUTE_TYPE", "int8")

# Segment merge tuning
MERGE_GAP_SEC = 0.3
PAD_SEC = 0.15

# Output cleanup (hours) - not actively scheduled in MVP, informational constant
OUTPUT_RETENTION_HOURS = 6
